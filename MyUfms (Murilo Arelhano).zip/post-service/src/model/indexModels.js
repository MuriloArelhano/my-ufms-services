// Imports para que o ORM indentifique as models e faça a sincronização com o banco de dados
let models = {
    post: require('./postModel')
}



module.exports = models