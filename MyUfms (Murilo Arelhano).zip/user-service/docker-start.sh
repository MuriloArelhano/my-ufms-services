rm -rf src
node ./build/server.js